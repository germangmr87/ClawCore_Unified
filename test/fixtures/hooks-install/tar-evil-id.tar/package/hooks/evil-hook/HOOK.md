---
name: evil-hook
description: evil-hook
metadata: {"clawcore":{"events":["command:new"]}}
---

# Hook