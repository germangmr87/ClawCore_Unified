---
name: tar-hook
description: tar-hook
metadata: {"clawcore":{"events":["command:new"]}}
---

# Hook