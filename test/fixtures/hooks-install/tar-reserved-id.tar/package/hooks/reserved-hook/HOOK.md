---
name: reserved-hook
description: reserved-hook
metadata: {"clawcore":{"events":["command:new"]}}
---

# Hook